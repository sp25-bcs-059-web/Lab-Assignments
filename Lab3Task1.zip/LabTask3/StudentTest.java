public class StudentTest {
    public static void main(String[] args) {

       
        Student s1 = new Student();

        
        Student s2 = new Student("Ali Khan", "Male", new Date(15, 3, 2002), "Lahore, Pakistan");


        Student s3 = new Student("SP25-BCS-999", "Sara Ahmed", "Female", new Date(7, 11, 2001), "Karachi, Pakistan");

      
      Student s4 =new Student(s2);
	  System.out.println("___Student Details___)");
	  System.out.println(s1);
      System.out.println("");
      System.out.println(s3);
      System.out.println("____________________");
      System.out.println(s4);
	  
	  System.out.println("___Equality Check___");
	  if (s2.equals(s4))
	  
		  System.out.println("Object s1 and s3 Are Equal");
	  
	  if (s1.equals(s3))
		  System.out.println("Object s1 and s3 Are Equal");
	  else 
		  System.out.println("Object s1 and s3 Are Not Equal");
    }
}

	

