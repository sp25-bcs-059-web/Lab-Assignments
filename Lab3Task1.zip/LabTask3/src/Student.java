public class Student {
    private String studentId;
    private String name;
    private String gender;
    private Date dateOfBirth;
    private String address;
	
	private static int idCounter = 1;

    public Student() {
        this.studentId = generateStudentId();
        this.name = "Unknown";
        this.gender = "Not specified";
        this.dateOfBirth = new Date(1, 1, 2000);
        this.address = "Not provided";
    }

    public Student(String studentId, String name, String gender, Date dateOfBirth, String address) {
        this.studentId = studentId;
        this.name = name;
        this.gender = gender;
        this.dateOfBirth = dateOfBirth;
        this.address = address;
    }

    public Student(String name, String gender, Date dateOfBirth, String address)
	{
        this.studentId = generateStudentId();
        this.name = name;
        this.gender = gender;
        this.dateOfBirth = dateOfBirth;
        this.address = address;
    }

    public Student(Student other) {
        this.studentId = other.studentId;
        this.name = other.name;
        this.gender = other.gender;
        this.dateOfBirth = new Date(
            other.dateOfBirth.getDay(),
            other.dateOfBirth.getMonth(),
            other.dateOfBirth.getYear()
        );
        this.address = other.address;
    }

    private String generateStudentId() {
        return String.format("SP25-BCS-%03d", idCounter++);
    }
	
    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public boolean equals(Student other) {
        if (other == null) return false;
        return this.studentId.equals(other.studentId) &&
               this.name.equals(other.name) &&
               this.gender.equals(other.gender) &&
               this.dateOfBirth.equals(other.dateOfBirth) &&
               this.address.equals(other.address);
    }
	
    @Override
    public String toString() {
        return String.format(
            "Student ID: %s\nName: %s\nGender: %s\nDate of Birth: %s\nAddress: %s",
            studentId, name, gender, dateOfBirth, address
        );
    }
}
